<div class="col-md-3">
    <div class="card">
        <div class="card-header">
            Sidebar
        </div>

        <div class="card-body">
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a href="{{ url('/admin') }}">
                        Dashboard
                    </a>            
                </li>
            </ul>
            <ul class="nav" role="tablist">         
                <li role="presentation">
                    <a href="http://mylist24.com/">
                        Site
                    </a>
                        //     
                     <a href="http://album-list.com/">
                        Album
                    </a>                        
                </li>
            </ul>         
            <ul class="nav" role="tablist">         
                <li role="presentation">
                    <a href="http://cinema-list.com/">
                        Cinema
                    </a>
                        //   
                    <a href="http://eiga-list.com/">
                        Eiga
                    </a>                        
                </li>
            </ul>
        </div>
    </div>
</div>
